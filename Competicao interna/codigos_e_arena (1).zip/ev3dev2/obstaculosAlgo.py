import ev3dev2.globalDefs as glob
import ev3dev2.sim as sim
from ev3dev2.motor import andar_em_metros, andar_livre, giro_livre, Stop as parar, TurnDirectionAng as girar_90_180, andar_frente_esquerda, andar_frente_direita
from ev3dev2.sensor import getColor as le_cor, getDistanceIR as le_distancia, getForce as le_forca, getCubeHandle
from ev3dev2.garraAlgo import fechar_garra_cubo, abrir_garra_cubo
import time

CorEsquerda = glob.color_sensor_Left
CorDireita = glob.color_sensor_Right
CorLateralEsq = glob.color_sensor_lateral_Left
SensorUsFrente = glob.us_front
SensorUsEsquerda = glob.us_left
SensorUsFrenteEsq = glob.us_front_left
SensorUsFrenteDir = glob.us_front_right
SensorForcaEsq = glob.sens_force_esq
SensorForcaDir = glob.sens_force_dir
SensorProxLateral = glob.sensor_proximidade_lat
SensorInfraEsq = glob.sensor_infra_esq
SensorInfraDir = glob.sensor_infra_dir
SensorInfraAtrasEsq = glob.sensor_infra_atras_esq
frente = glob.frente
tras = glob.tras
horario = glob.horario
antihorario = glob.antihorario
cubo = glob.cubo



def segue_linha(velocidade):
    velocidade_giro = 8 #antiga 2
    #tirei " (le_cor(CorLateralEsq) != -10) and " do começo do while
    while (le_cor(CorLateralEsq) != -10 or le_distancia(SensorProxLateral) > 0.5) and (le_distancia(SensorUsFrente) > 0.17) and (le_distancia(SensorUsFrenteEsq) > 0.17) and (le_distancia(SensorUsFrenteDir) > 0.17) and (le_cor(CorDireita) == glob.BRANCO or le_cor(CorDireita) == glob.PRETO):# and (le_cor(CorDireita) != glob.PRETO or le_cor(CorEsquerda) != glob.PRETO): ##condição para parar quando chegasse no final do percurso, mas essa não funciona direito. Talvez botar aqui outra condição para caso ele veja as cores ou chegue na torre de hanoi
        andar_livre(frente, velocidade)
        # aux = 0

        # if le_cor(CorLateralEsq) == -20:
        #     print('aux = 1')
        #     aux = 1
        
        # if aux == 1 and le_cor(CorLateralEsq) == -10: #por algum motivo não ta entrando nesse if mesmo se o aux foi 1
        #     print('break do aux')
        #     break

        # if le_cor(CorLateralEsq) == -10:
        #     # print('break sem aux')
        #     break


        if le_distancia(SensorUsFrente) <= 0.23: #detectou um bloco, pode ser o parado ou o que se mexe
            parar()
            time.sleep(6)
            if le_distancia(SensorUsFrente) <= 0.23: #é o bloco parado
                while le_cor(CorEsquerda) == glob.PRETO: #alinhar o robô
                    # print('alinhou esquerda')
                    giro_livre(antihorario, 5)
                while le_cor(CorDireita) == glob.PRETO:
                    # print('alinhou direita')
                    giro_livre(horario, 5)
                # print('bloco parado')
                # print(le_distancia(SensorUsFrente))
                break
            else: #é o bloco que se mexe
                andar_livre(frente, velocidade)


                # if le_distancia(SensorUsFrenteEsq) != 1 or le_distancia(SensorUsFrenteDir) != 1: #detectou algum bloco
                #     parar()
                #     if le_distancia(SensorUsFrenteEsq) == 1 and le_distancia(SensorUsFrenteDir) == 1: #mesmo parado parou de detectar o bloco, então é o bloco que se mexe
                #         if le_distancia(SensorUsFrenteEsq) != 1 or le_distancia(SensorUsFrenteDir) != 1: #detectou o bloco que se mexe de novo
                #             velocidade = 20
                #     else:
                #         velocidade = 10

        # if le_distancia(SensorUsFrente) != 1:
        #     andar_livre(frente, 5)
        #     # parar()
        #     # while le_distancia(SensorUsFrente) > 0.2:
        #     #     andar_livre(frente, 5) #antiga 0.5
        #     # parar()


        if le_cor(CorEsquerda) == glob.PRETO or le_cor(CorDireita) == glob.PRETO:
            tempo_inicial = time.time()
            esq = 0
            dir = 0

            while le_cor(CorEsquerda) == glob.PRETO:
                andar_frente_direita(frente, velocidade_giro)
                esq = 1
            while le_cor(CorDireita) == glob.PRETO:
                andar_frente_esquerda(frente, velocidade_giro)
                dir = 1

            tempo_final = time.time()
            delta_tempo = tempo_final - tempo_inicial

            if delta_tempo > 0.22: #era 0.2      antigo 0.15 tempo que o sensor precisa ficar em cima da linha para que seja feito o ajuste
                if esq == 1:
                    andar_frente_direita(frente, velocidade_giro)
                    time.sleep(0.165) #tempo extra que o robô gira para compensar e evitar sair da linha
                    parar()
                    # print('FEZ O AJUSTE NA ESQUERDA') #teste
                    while le_cor(CorDireita) != glob.PRETO: #caso ainda precise fazer mais ajuste
                        andar_frente_direita(frente, velocidade_giro)
                        # time.sleep(0.1) #tempo extra que o robô gira para compensar e evitar sair da linha
                        # print('fez o ajuste novo esquerda') #teste
                    parar()
                elif dir == 1:
                    andar_frente_esquerda(frente, velocidade_giro)
                    time.sleep(0.165) #tempo extra que o robô gira para compensar e evitar sair da linha
                    parar()
                    # print('FEZ O AJUSTE NA DIREITA') #teste
                    while le_cor(CorEsquerda) != glob.PRETO: #caso ainda precise fazer mais ajuste
                        andar_frente_esquerda(frente, velocidade_giro)
                        # time.sleep(0.1) #tempo extra que o robô gira para compensar e evitar sair da linha
                        # print('fez o ajuste novo direita') #teste
                    parar()
    parar()
    # print('saiu do segue linha') #teste


def desvia_obst_parado():
    girar_90_180(horario, 90)
    while le_distancia(SensorUsEsquerda) != 1:
        andar_livre(1, 8)
    time.sleep(0.7) #ver o tempo aqui, tem que esperar para o robo passar um pouco do bloco, para que quando ele gire ele não bata no bloco
    parar()

    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.3) #anda 30cm para a frente, pois ele para a 20cm do cubo e o cubo tem no mínimo 15cm, ai 30cm fica uma distância boa pra ele andar
    while le_distancia(SensorUsEsquerda) != 1:
        andar_livre(1, 8)
    time.sleep(0.7) #ver o tempo aqui, tem que esperar para o robo passar um pouco do bloco, para que quando ele gire ele não bata no bloco
    parar()

    girar_90_180(antihorario, 90)

    while le_cor(CorEsquerda) == glob.BRANCO:
        andar_livre(frente, 5)
    time.sleep(0.65) #ver o tempo aqui, tem que esperar para parar, para que o robo fique centralizado com a linha
    parar()
    girar_90_180(horario, 90)

def desvia_obst_mexe():
    # if le_distancia(SensorUsFrente) < 0.5: #detectando o bloco
        if le_distancia(SensorUsFrente) == 1: #não detectando o bloco
            andar_em_metros(frente, 15, 0.5)


def girar_e_alinhar_com_cubo(clientID, _robotFrontRightMotor, _robotFrontLeftMotor, _robotBackRightMotor, _robotBackLeftMotor, _robo, d):
    # d = 1 , anti horario, esquerda
    # d =-1 , horario, direita

    v = 3.5 #se v = 2, passo = 0.0008
    passo = 0.0008

    sim.simxPauseCommunication(clientID, True)
    sim.simxSetJointTargetVelocity(clientID,_robotFrontRightMotor,(-1)*d*v, sim.simx_opmode_oneshot)
    sim.simxSetJointTargetVelocity(clientID,_robotFrontLeftMotor,d*v, sim.simx_opmode_oneshot)
    sim.simxSetJointTargetVelocity(clientID,_robotBackRightMotor,(-1)*d*v, sim.simx_opmode_oneshot)
    sim.simxSetJointTargetVelocity(clientID,_robotBackLeftMotor,d*v, sim.simx_opmode_oneshot)
    sim.simxPauseCommunication(clientID, False)

    time.sleep(0.3) #delay para que o robô gire um pouco e fique deslinhado com o cubo que ele acabou de deixar no chão, se não fizer isso ele ja vai começar o giro alinhado com o cubo que ele acabou se soltar e ai ele não vai girar
    while True:
        if (le_distancia(SensorInfraEsq) != 1) and (le_distancia(SensorInfraDir) != 1):
            if abs(le_distancia(SensorInfraEsq) - le_distancia(SensorInfraDir)) < passo:
                # print('diferença: ', abs(le_distancia(SensorInfraEsq) - le_distancia(SensorInfraDir))) #teste
                break
    parar()



def torre_de_hanoi(): #tem que achar uma condicional pra por na função de segue linha e na main pra saber quando chegou na torre de hanoi
    #https://www.youtube.com/watch?v=cHkDaotS5k8&ab_channel=ProfGilberto%E2%80%9CGilmate%E2%80%9D
    while(le_cor(CorEsquerda) != 0) and (le_cor(CorDireita) != 0): #talvez tenha que mudar a condição
        andar_livre(frente, 10)
    time.sleep(0.37) #delay para o robô ficar alinhado com os cubos
    parar()
    girar_90_180(antihorario, 90)

    while le_distancia(SensorUsFrente) > 0.066:
        andar_livre(frente, 10)
    parar()
    #Verificar e modificar todas as distancias

    #Movimento 1 - OK (Disco 1 pro meio)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.122)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.05)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.07)

    #Movimento 2 - OK (Disco 2 pro canto)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.16)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.16)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 3 - OK (Disco 1 pro canto)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.05)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.05)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 4 (Disco 3 pro meio)
    girar_90_180(antihorario, 90)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.23)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.23)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.13)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.13)

    #Movimento 5 (Disco 1 pro inicio)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.02)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.02)
    girar_90_180(antihorario, 90)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 6 (Disco 2 pro meio)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 7 (Disco 1 pro meio)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.20)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 8 (Disco 4 pro canto - metade da torre feita)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.25)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.25)
    girar_90_180(antihorario, 90)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.25)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.25)

    #Movimento 9 (Disco 1 pro canto)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.02)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.02)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 10 (Disco 2 pro inicio)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 11 (Disco 1 pro inicio)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.20)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 12 (Disco 3 pro canto)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.12)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.12)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 13 (Disco 1 pro meio)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.025)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.025)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 14 (Disco 2 pro canto)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.15)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.15)

    #Movimento 15 (Disco 1 pro canto)
    girar_90_180(antihorario, 90)
    andar_em_metros(frente, 10, 0.025)
    cubo0 = getCubeHandle(SensorUsFrente)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.025)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.10)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.10)

def torre_de_hanoi_v2(): #tem que achar uma condicional pra por na função de segue linha e na main pra saber quando chegou na torre de hanoi
    #https://www.youtube.com/watch?v=cHkDaotS5k8&ab_channel=ProfGilberto%E2%80%9CGilmate%E2%80%9D

    # while (le_cor(CorEsquerdaLinha) == glob.PRETO) or (le_cor(CorDireitaLinha) == glob.PRETO):
    #     alinhar_linha()
    
    # while (le_cor(CorEsquerda) != 0) and (le_cor(CorDireita) != 0): #talvez tenha que mudar a condição
    #     andar_livre(frente, 10)
    # time.sleep(0.37) #delay para o robô ficar alinhado com os cubos
    # parar()
    # andar_em_metros(frente, 10, 0.1)
    # girar_90_180(antihorario, 90)


    while le_cor(CorDireita) != glob.PRETO and le_cor(CorEsquerda) != glob.PRETO:
        andar_livre(frente, 10)
    parar()
    while le_distancia(SensorInfraAtrasEsq) == 1:
        andar_livre(frente, 4)
    parar()
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)


    while le_distancia(SensorUsFrente) > 0.066:
    # while le_distancia(SensorInfraDir) > 0.1:
        # print(le_distancia(SensorInfraDir)) #teste
        andar_livre(frente, 10)
    parar()
    #Verificar e modificar todas as distancias

    #Movimento 1 - OK (Disco 1 pro meio)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.12)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.05)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.09)

    #Movimento 2 - OK (Disco 2 pro canto)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.16)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.16)
    girar_90_180(horario, 90)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 3 - OK (Disco 1 pro canto)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.05)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.05)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.05)

    #Movimento 4 (Disco 3 pro meio)
    # girar_90_180(antihorario, 90)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.23)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.23)
    girar_90_180(horario, 90)
    andar_em_metros(frente, 10, 0.13)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.13)

    #Movimento 5 (Disco 1 pro inicio)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.02)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.05)
    # girar_90_180(antihorario, 90)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario) #aqui foi horário pra ele não ver os cubos no meio e ir pro inicio
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 6 (Disco 2 pro meio)
    # girar_90_180(horario, 90)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario) #aqui foi antihorário pra ele não ver os cubos no meio e ir pro canto
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 7 (Disco 1 pro meio)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.20)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 8 (Disco 4 pro canto - metade da torre feita)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.25)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.25)
    # girar_90_180(antihorario, 90)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario) #aqui foi antihorário pra ele não ver os cubos no meio e ir pro canto
    andar_em_metros(frente, 10, 0.25)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.25)

    #Movimento 9 (Disco 1 pro canto)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.02)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.02)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 10 (Disco 2 pro inicio)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    girar_90_180(antihorario, 90) #continua essa função de giro, pois não tem cubo no início, então não teria como se alinhar
    andar_em_metros(frente, 10, 0.08)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)

    #Movimento 11 (Disco 1 pro inicio)
    # girar_90_180(horario, 90)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario) #aqui foi antihorário pra ele não ver os cubos no meio e ir pro canto
    andar_em_metros(frente, 10, 0.20)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)
    # girar_90_180(horario, 90)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario) #aqui foi horário pra ele não ver os cubos no meio e ir pro início
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 12 (Disco 3 pro canto)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.12)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.12)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.20)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.20)

    #Movimento 13 (Disco 1 pro meio)
    # girar_90_180(horario, 90)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.025)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.025)
    girar_90_180(horario, 90) ##continua essa função de giro, pois não tem cubo no meio, então não teria como se alinhar
    andar_em_metros(frente, 10, 0.03)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.03)

    #Movimento 14 (Disco 2 pro canto)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.08)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.08)
    # girar_90_180(horario, 90)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario) #aqui foi antihorário pra ele não ver os cubos no meio e ir pro canto
    andar_em_metros(frente, 10, 0.15)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.15)

    #Movimento 15 (Disco 1 pro canto)
    # girar_90_180(antihorario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, antihorario)
    andar_em_metros(frente, 10, 0.025)
    cubo0 = getCubeHandle(SensorInfraDir)
    fechar_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.025)
    # girar_90_180(horario, 90)
    girar_e_alinhar_com_cubo(glob.clientID, glob.robotFrontRightMotor, glob.robotFrontLeftMotor, glob.robotBackRightMotor, glob.robotBackLeftMotor, glob.robo, horario)
    andar_em_metros(frente, 10, 0.10)
    abrir_garra_cubo(cubo0)
    andar_em_metros(tras, 10, 0.10)