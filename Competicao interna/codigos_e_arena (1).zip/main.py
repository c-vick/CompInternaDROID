from ev3dev2.motor import andar_em_metros, andar_livre, giro_livre, Stop as parar, TurnDirectionAng as girar_90_180
from ev3dev2.sensor import getColor as le_cor, getDistanceIR as le_distancia, getForce as le_forca
import ev3dev2.globalDefs as glob
import ev3dev2.sim as sim
import time
from ev3dev2.garraAlgo import fechar_garra, abrir_garra, fechar_garra_cubo, abrir_garra_cubo
from ev3dev2.obstaculosAlgo import segue_linha, desvia_obst_parado, desvia_obst_mexe, torre_de_hanoi, torre_de_hanoi_v2
from ev3dev2.coresAlgo import dancinha, dancinha_v2, dancinha_v3
import numpy as np

CorEsquerda = glob.color_sensor_Left
CorDireita = glob.color_sensor_Right
CorLateralEsq = glob.color_sensor_lateral_Left
SensorUsFrente = glob.us_front
SensorUsEsquerda = glob.us_left
SensorUsFrenteEsq = glob.us_front_left
SensorUsFrenteDir = glob.us_front_right
SensorForcaEsq = glob.sens_force_esq
SensorForcaDir = glob.sens_force_dir
SensorProxLateral = glob.sensor_proximidade_lat
SensorInfraEsq = glob.sensor_infra_esq
SensorInfraDir = glob.sensor_infra_dir
SensorInfraAtrasEsq = glob.sensor_infra_atras_esq
frente = glob.frente
tras = glob.tras
horario = glob.horario
antihorario = glob.antihorario
cubo = glob.cubo

#################################################################################

# Nomes dos Sensores:
# Ultrassom:
# 	SensorUsFrente
#	SensorUsEsquerda
# Cor:
#	CorEsquerda
#	CorDireita

# PRETO = 0
# VERMELHO = 1
# AMARELO = 2
# VERDE = 3
# AZUL = 5
# BRANCO = 6

# Funções movimento:
#	andar_em_metros(direção, velocidade, metros)
#	andar_livre(direção, velocidade)
#	giro_livre(orientação, velocidade)
#	parar()
#	girar_90_180(orientação, ângulo)
#
# Funções sensores:
#	le_cor(sensor)
#	le_distancia(sensor)


# ESCREVER SEU CÓDIGO AQUI:
#################################################################################

# fechar_garra()
# fechar_garra_cubo(cubo)
# time.sleep(1)
# andar_em_metros(frente, 1, 0.3)
# abrir_garra_cubo(cubo)

# segue_linha(1.5)
# andar_em_metros(frente, 5, 0.5) #teste obst mexe
# segue_linha(1.5) #teste obst mexe
# desvia_obst_parado() #teste do inicio
# segue_linha(1.5) #teste do inicio
# dancinha_v2() #teste do inicio
# segue_linha(1.5) #teste do inicio
# andar_em_metros(frente, 2, 0.04) #isso é para passar a segunda linha amarela do quadrado de onde faz a dancinha #teste do inicio
# segue_linha(1.5) #teste do inicio

#acho que esse seria o código final
# time.sleep(15)
andar_em_metros(frente, 10, 0.2)
while True:
    segue_linha(10)
    if (0.19 < le_distancia(SensorUsFrente) <= 0.23) and (le_distancia(SensorUsFrenteDir) > 0.17 and le_distancia(SensorUsFrenteEsq) > 0.17):
        #talvez aqui eu posso botar um código pra alinhar o robô
        desvia_obst_parado()
        # time.sleep(3)
        # if le_distancia(SensorUsFrente) <= 0.2:
        #     #talvez aqui eu posso botar um código pra alinhar o robô
        #     desvia_obst_parado()

    # if le_distancia(SensorUsFrente) <= 0.2:
    #     time.sleep(3)
    #     if le_distancia(SensorUsFrente) > 0.2:
    #         desvia_obst_mexe()
    #     else:
    #         desvia_obst_parado()


        # tempo_inicial = time.time()
        # tempo_final = 0
        # if le_distancia(SensorUsFrente) > 0.2:
        #     print('sensor > 0.2')
        #     tempo_final = time.time()
        # delta_tempo = tempo_final - tempo_inicial
        # if tempo_final != 0:
        #     print('desvia obst mexe')
        #     desvia_obst_mexe()
        # elif tempo_final == 0:
            # print('desvia obst parado')
            # desvia_obst_parado()

            
    if le_cor(CorDireita) != glob.BRANCO and le_cor(CorDireita) != glob.PRETO:
        dancinha_v3()
    # if le_cor(CorDireita) == glob.PRETO and le_cor(CorEsquerda) == glob.PRETO: #acho que essa condição não funciona direito, pois nem sempre o robô chega alinhado certinho no final e ai ele ja começa a girar pra um lado, antes que o outro lado detecte a linha preta
    if le_cor(CorLateralEsq) == -10:
        torre_de_hanoi_v2()
        # print('torre de hanoi')
        break










# cores = []
# cores.append(6)

# for i in range (4): #le as cores e salva em uma lista
#     while le_cor(CorEsquerda) == cores[i] and le_cor(CorDireita) == cores[i]: #verifica os dois sensores, talvez possa verificar só um
#         andar_livre(frente, 3)
#     parar()
#     cores.append(le_cor(CorEsquerda))
# print(cores) #teste

# if cores[1] == glob.VERDE and cores[2] == glob.VERMELHO and cores[3] == glob.AZUL:
#     path = 1
# elif cores[1] == glob.VERMELHO and cores[2] == glob.AMARELO and cores[3] == glob.VERDE:
#     path = 2
# elif cores[1] == glob.AZUL and cores[2] == glob.VERDE and cores[3] == glob.AMARELO:
#     path = 3
# elif cores[1] == glob.VERMELHO and cores[2] == glob.AZUL and cores[3] == glob.AMARELO:
#     path = 4
# elif cores[1] == glob.AMARELO and cores[2] == glob.VERDE and cores[3] == glob.AZUL:
#     path = 5
# elif cores[1] == glob.AZUL and cores[2] == glob.VERMELHO and cores[3] == glob.VERDE: #podia ser um else
#     path = 6
# print(path) #teste

# while le_distancia(SensorUsEsquerda) != 1: #andar até o vão na parede
#     andar_livre(frente, 3)
# time.sleep(0.2) #esperar um pouco para não bater o lado esquerdo quando for passar pelo vão
# parar()

# # giro_livre(antihorario, 0.5) #girar para passar pelo vão
# # time.sleep(1.32)
# # parar()
# girar_90_180(antihorario, 90) #girar para passar pelo vão

# andar_em_metros(frente, 3, 0.6) #passar pelo vão

# if path == 1 or path == 2 or path == 3:
#     # giro_livre(antihorario, 0.5) #girar aproximadamente 90º para a esquerda
#     # time.sleep(1.2)
#     # parar()
#     girar_90_180(antihorario, 90)  #girar aproximadamente 90º para a esquerda
#     andar_em_metros(frente, 3, 1.4)
#     if path == 1:
#         andar_em_metros(frente, 3, 0.9)
#     elif path == 2:
#         andar_em_metros(frente, 3, 0.425)
#     # giro_livre(horario, 0.5) #girar aproximadamente 90º para a direita
#     # time.sleep(1.2)
#     # parar()
#     girar_90_180(horario, 90) #girar aproximadamente 90º para a direita
#     while le_distancia(SensorUsFrente) > 0.3: #andar até a parede
#         andar_livre(frente, 3)
#     parar()

# if path == 4 or path == 5 or path == 6:
#     # giro_livre(horario, 0.5) #girar aproximadamente 90º para a direita
#     # time.sleep(1.2)
#     # parar()
#     girar_90_180(horario, 90) #girar aproximadamente 90º para a direita
#     andar_em_metros(frente, 3, 0.8)
#     if path == 5:
#         andar_em_metros(frente, 3, 0.425)
#     elif path == 6:
#         andar_em_metros(frente, 3, 0.9)
#     # giro_livre(antihorario, 0.5) #girar aproximadamente 90º para a esquerda
#     # time.sleep(1.2)
#     # parar()
#     girar_90_180(antihorario, 90)  #girar aproximadamente 90º para a esquerda
#     while le_distancia(SensorUsFrente) > 0.3: #andar até a parede
#         andar_livre(frente, 3)
#     parar()

#################################################################################
	
# Pause simulation
clientID = glob.clientID
#sim.simxPauseSimulation(clientID,sim.simx_opmode_oneshot_wait)

# Now close the connection to V-REP:
#sim.simxAddStatusbarMessage(clientID, 'Programa pausado', sim.simx_opmode_blocking )
sim.simxFinish(clientID)
print ('Program ended')